import time
import pandas as pd
import numpy as np

CITY_DATA = { 'chicago': 'chicago.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }

def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    print('Hello! Let\'s explore some US bikeshare data!')
    # TO DO: get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs
    valid_city = ['chicago','new york city','washington']
    city = 0
    while city not in valid_city:
       city = input('would you like to filter the data ?\n kindly type: \n Chicago \n New York City \n Washington \n').lower()
        
    months = ['all','january','februray','march','april','june']
    month = 0
    while month not in months:
        month = input('would you like to filter the data by month?\n kindly choose:\n January \n February \n March \n April \n June \n All \n').lower()
        
    days = ['all','monday','tuesday','wednesday','thursday','friday','saturday','sunday']
    day = 0
    while day not in days:
      day = input('would you like to filter the data by day? \n kindly choose: \n Monday \n Tuesday \n Wednesday \n Thursday \n Friday \n Saturday \n Sunday \n All \n').lower()
               
    print('-'*40)
    return city, month, day


def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """
    df = pd.read_csv(CITY_DATA[city])
    print(df)
    
    
    df['Start Time'] = pd.to_datetime(df['Start Time'])
    df['month'] = df['Start Time'].dt.month
    df['day_of_week'] = df['Start Time'].dt.weekday_name

 
    if month != 'all':
        months = ['january', 'february', 'march', 'april', 'may', 'june']
        month = months.index(month) + 1
        df = df[df['month'] == month]

    if day != 'all':
        df = df[df['day_of_week'] == day.title()]

    return df


def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()
                
    # TO DO: display the most common month
    common_month = df['month'].mode()[0]
    print('The most common month:', common_month)
       
    # TO DO: display the most common day of week
    common_day = df['day_of_week'].mode()[0]
    print('The most common day:', common_day)

    # TO DO: display the most common start hour
    df['hour'] = df['Start Time'].dt.hour
    popular_hour = df['hour'].mode()[0]
    print('The most popular hour:', popular_hour)


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # TO DO: display most commonly used start station
    common_start_station = df['Start Station'].mode()[0]
    print('The most common start station:', common_start_station)
    
    # TO DO: display most commonly used end station
    common_end_station = df['End Station'].mode()[0]
    print('The most common end station:', common_end_station)
    
    # TO DO: display most frequent combination of start station and end station trip
    df["rout"] = df["Start Station"] + "-" + df["End Station"] 
    freq_comb_rout = df['rout'].mode()[0]
    print('The most frequent combination of start and end station :', freq_comb_rout)

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # TO DO: display total travel time
    df['End Time'] = pd.to_datetime(df['End Time'])
    df['Travel Duration'] = df['End Time'] - df['Start Time']
    total_travel_time = df['Travel Duration'].sum()
    print('Total travel time :', total_travel_time)

    # TO DO: display mean travel time
    mean_travel_time = df['Travel Duration'].mean()
    print('Mean travel time :', mean_travel_time)

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def user_stats(df,city):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # TO DO: Display counts of user types
    user_types = df['User Type'].value_counts()
    print(user_types)

    # TO DO: Display counts of gender
    if city == "washington":
        print('Gender not available')
    else:
        gender_type = df['Gender'].value_counts()
        print(gender_type)

    # TO DO: Display earliest, most recent, and most common year of birth
    if city == "washington":
        print('Birth year not available')
    else:
       earliest_birth_year = df['Birth Year'].min()
       recent_birth_year = df['Birth Year'].max()
       common_birth_year = df['Birth Year'].mode()[0]
       print('Earliest year of birth:', earliest_birth_year,'Recent year of birth:', recent_birth_year,'Common year of birth:\n', common_birth_year)

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)
    
def display_raw_data(df):

    start_loc = 0
    display_opt = input('To View the availbale raw data in chuncks of 5 rows type: Yes \n').lower()
    while display_opt not in ['yes', 'no']:
        print('That\'s invalid choice, please type yes or no')
        display_opt = input('To View the availbale raw data in chuncks of 5 rows type: Yes \n').lower()
    while display_opt == 'yes':
        print(df.iloc[start_loc:start_loc+5])
        start_loc+=5
        display_opt = input('Do you want to display 5 more rows? yes or no: ').lower()
    if display_opt == 'no':
        print('\nExiting...')


def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df,city)
        display_raw_data(df)

        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break


if __name__ == "__main__":
	main()
